
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: ${date}     ⏰ Hora: ${time}
 *
 *  Nombre del programa : ${name}
 *
 *******************************************************/

/********************************* ENUNCIADO ***********************************

*******************************************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package ${package};
import java.util.Scanner;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: ${date} ⏰ Hora: ${time}
* @version 1.0
*******************************************************************************/

public class ${name} {

    public static void main(String[] args) {

        // Declaración de variables y constantes
        
        // Lectura y comprobación de datos introducidos por teclado
        Scanner sc = new Scanner(System.in);
        
        // Empezamos a crear el interior del programa

        // Mostramos el resultado

    } //main()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘