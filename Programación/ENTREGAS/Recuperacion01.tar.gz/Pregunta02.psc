Algoritmo Pregunta02
	
	Definir i, opc, n1, n2, suma Como Entero
	Definir detener Como Logico
	
	i = 0
	detener = falso
	suma = 0
	
	Repetir
		Escribir "Elige una opcion (1-3)"
		Escribir "1. Multiplos de 3 y 5 simultaneamente."
		Escribir "2. Contador de n�meros."
		Escribir "3. Salir."
		Leer opc
		Segun opc Hacer
			1:
				Escribir "Introduzca 10 n�meros enteros positivos."
				Mientras i<10 Hacer
					Escribir "Introduzca un n�mero: "
					Leer n1
					Si n1%3 == 0 y n1%5 == 0 Entonces
						Escribir "El n�mero es multiplo de 3 y 5 simultaneamente."
					SiNo
						Escribir "El n�mero NO es multiplo de 3 y 5 simultaneamente."
					Fin Si
					i = i+1
				Fin Mientras
			2:
				Escribir "Introduzca n�meros positivos (se detendra cuando sea un n�mero negativo)"
				Mientras n2>=0 Hacer
					Escribir "Introduzca un n�mero: "
					Leer n2
					Si n2>=0 Entonces
						suma = suma + n2;
					Fin Si
				Fin Mientras
				Escribir "SUMA TOTAL:" suma
			3: 
				Escribir "Saliendo del programa"
				detener = Verdadero
			De Otro Modo:
				Escribir "ERROR. Opcion incorrecta escribe un n�mero del 1 al 3."
		Fin Segun
	Hasta Que detener == Verdadero 
	
FinAlgoritmo
