
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 23 ene 2026     ⏰ Hora: 9:04:14
 *
 *  Nombre del programa : Pregunta01
 *
 *******************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package recuperacion;

public class Pregunta01 {

    public static void main(String[] args) {

        // Declaración de variables y constantes
        final int FILAS = 10;
        final int COLUMNAS = 10;
        int n, contadorArray = 0, max = 200, min = 300, contadorI = 0, contadorJ = FILAS-1;
        int[] diaganoles = new int[FILAS]; // Creacion de array de 1 dimension
        
        
        // Empezamos a crear el array
        for (int i = 0; i < FILAS; i++) { // FILAS
            for (int j = 0; j < COLUMNAS; j++) { // COLUMNAS
                n = (int)((Math.random() * 101) +200); // Calculamos el número aleatorio
                System.out.print(n + "   "); // Mostramos el número aleatorio
                
                if (contadorArray<(COLUMNAS/2)) { // Para la mitad de las diagonales de la izquierda
                    if (i == j) {
                        diaganoles[contadorArray] = n; // la guardamos
                        contadorArray++;
                        if (max < n) max = n; // hallamos el max
                        if (min > n) min = n; // hallamos el min
                    }
                }
                
                if (contadorArray>=(COLUMNAS/2)) { // Para la mitad de las diagonales de la derecha
                    if (i == contadorI && contadorJ == j) {
                        diaganoles[contadorArray] = n; // la guardamos
                        contadorArray++;
                        if (max < n) max = n; // hallamos el max
                        if (min > n) min = n; // hallamos el min
                        contadorI++;
                        contadorJ--;
                    }
                }
            }
            System.out.println();  // Salto de linea
        }
        
        // Mostramos el resultado
        System.out.println("\nMEDIAS DIAGONALES");
        for (int i = 0; i < diaganoles.length; i++) { // Mostramos las diagonales
            System.out.print(diaganoles[i] + "  ");
        }
        
        System.out.println("\n\nMaximo: " + max);
        System.out.println("Minimo: " + min);

    } //main()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘