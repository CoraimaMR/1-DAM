
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 28 ene 2026     ⏰ Hora: 11:56:38
 *
 *  Nombre del programa : Pregunta01
 *
 *******************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package pregunta01;

public class main {

    public static void main(String[] args) {
        //Jugadores titulares
        Jugador j1=new Jugador("Chacho", 195, 1);
        Jugador j2=new Jugador("Gasol", 210, 5);
        
        //Jugador suplente
        Jugador j3=new Jugador("Alberto", 193);
        
        //Anotan canasta
        j1.anotar(1);
        j2.anotar(2);
        j3.anotar(3);
        
        //Imprimo información
        System.out.println("");
        System.out.println(j1.toString());
        System.out.println(j2.toString());
        System.out.println(j3.toString());

        //Hacen falta
        //j1 comete 3 faltas
        j1.falta(3);
        //j2 comete 2 faltas
        j2.falta(2);
        //j3 comete 1 falta
        j3.falta(1);
              
        //Imprimo información
        System.out.println("");
        System.out.println(j1.toString());
        System.out.println(j2.toString());
        System.out.println(j3.toString());
        
        //Sale j3
        j3.sale();
        
        //Entra j3
        j3.entra(1);
        j1.sale();
        
        //Cometen más faltas
        //j2 comete 2 faltas
        j2.falta(2);
        //j3 comete 1 falta
        j3.falta(1);
        //j2 comete 1 falta
        j2.falta(1);
                
        //Imprimo información
        System.out.println("");
        System.out.println(j1.toString());
        System.out.println(j2.toString());
        System.out.println(j3.toString());
        
        //j2 comete falta
        j2.falta(1);
                
    }//main
    
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘