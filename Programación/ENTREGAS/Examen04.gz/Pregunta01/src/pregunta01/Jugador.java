
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package pregunta01;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 28 ene 2026 ⏰ Hora: 12:01:15
* @version 1.0
*******************************************************************************/

public class Jugador {
    
    //---- CONSTANTES ESTATICAS ----
    private final static String NOMBRE_CLUB = "Club Baloncesto Rota";
    private final static int MAX_FALTAS = 5;
    private final static int MAX_PUNTOS = 3;
    private final static int MIN_PUNTOS = 1;
    private final static int MAX_POSICION = 5;
    private final static int MIN_POSICION= 1;
    
    // ---- VARIABLES ESTATICAS ----
    private static int categoriaMilita = 4;
    
    // --------- VARIABLES ---------
    private String nombre;
    private int altura;
    private int puntos;
    private int faltas;
    private int posicion;
    private boolean expulsado;
    private boolean pista;
    
    // -------- CONSTRUCTOR --------
    public Jugador(String nombre, int altura, int posicion) {
        // Info que pide al crear
        this.nombre = nombre;
        this.altura = altura;
        this.posicion = posicion;
        
        // Valores que podemos saber
        this.pista = true;
        
        // Valores predeterminados
        this.puntos = 0;
        this.faltas = 0;
        this.expulsado = false;
    } // CONSTRUCTOR
    
    public Jugador(String nombre, int altura) {
        // Info que pide al crear
        this.nombre = nombre;
        this.altura = altura;
        
        // Valores que podemos saber
        this.pista = false;
        
        // Valores predeterminados
        this.puntos = 0;
        this.faltas = 0;
        this.expulsado = false;
    } // CONSTRUCTOR
    
    // ---------- GETTERS ----------

    public static int getCategoriaMilita() {
        return categoriaMilita;
    }

    public String getNombre() {
        return nombre;
    }

    public int getAltura() {
        return altura;
    }

    public int getPuntos() {
        return puntos;
    }

    public int getFaltas() {
        return faltas;
    }

    public int getPosicion() {
        return posicion;
    }

    public boolean isExpulsado() {
        return expulsado;
    }

    public boolean isPista() {
        return pista;
    }
    
    //---- METODOS DE LA CLASE -----
    
    public void anotar(int i) { // Metodo de clase para anotar
        if (this.pista) { // // Si el jugador esta en pista seguimos
            if (i >= MIN_PUNTOS || i <= MAX_PUNTOS) { // Si los puntos son correctos seguimos
              this.puntos += i; // Sumamos los puntos
            }else{ // Si los puntos son incorrectos mostramos:
                System.out.println("ERROR. Puntos no validos.");
            }
        }else{ // Si no esta en cancha mostramos:
            System.out.println("ERROR. El jugador no esta en la pista y no puede anotar.");
        }
    } // anotar(int i)
    
    public void entra(int i) { // Metodo de clase para entrar en cancha
        if (!expulsado) { // Si no esta expulsado seguimos
            if (i <= MAX_POSICION && i >= MIN_POSICION) { // Si la posicion es correcta seguimos
                this.posicion = i; // Ponemos su posicion
                this.pista = true; // Ponemos que esta en pista
            } else { // Si su posicion no es valida mostramos:
                System.out.println("ERROR. Posición va válida.");
            }
        }else{ // si esra expulsado mostramos:
            System.out.println("ERROR. El jugador esta expulsado y no puede entrar.");
        }
    } // entra(int i)
    
    public void sale() { // Metodo de clase para salir de cancha
        this.pista = false; // Asignamos que no esta en pista
        this.posicion = 0; // Al salir no tiene posicion
    } // sale()
    
    public void falta(int i) { // Metodo de clase para calcular faltas
        if (this.pista && !this.expulsado) { // Si esta en pista y no esta expulsado seguimos
            this.faltas += i; // sumamos sus faltas
            if (this.faltas >= MAX_FALTAS) { // Si sus faltas son mayores o iguales al maximo:
                this.expulsado = true; // lo expulsamos
                sale(); // lo sacamos de la pista
                System.out.println("El jugador a cometido las maximas faltas y esta expulsado."); // y mostramos esto.
            }
        }else{ // Si el jugador no esta en cancha o esta expulsado
                if (this.expulsado) { // si esta expulsado mostramos:
                    System.out.println("ERROR. Ya esta expulsado y no puede cometer mas faltas.");
                } else { // Si no esta en cancha mostramos:
                    System.out.println("ERROR: No esta en cancha y no puede cometer faltas.");
                }
            }
    } // falta(int i)
    
    @Override
    public String toString() { // Metodo de clase para imprimir
        return "Jugador{" + "nombre=" + nombre + ", altura=" + altura + ", puntos=" + puntos + ", faltas=" + faltas + '}';
    } // toString()
    
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘