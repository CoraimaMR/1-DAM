
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package pregunta02;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 28 ene 2026 ⏰ Hora: 13:20:35
* @version 1.0
*******************************************************************************/

public class Libro {
    
    //---- CONSTANTES ESTATICAS ----
    private static final String COLLECION = "Novela negra";

    // ---- VARIABLES ESTATICAS ----
    private final String ISBN;
    private final String TITULO;
    private final String AUTOR;
    
    // --------- VARIABLES ---------
    private String nacionlaidad;
    private int paginas;
    
    // -------- CONSTRUCTOR --------
    Libro(String ISBN, String AUTOR, String TITULO) {
        // Info que pide al crear
        this.AUTOR = AUTOR;
        this.ISBN = ISBN;
        this.TITULO = TITULO;
    }

    Libro(String ISBN, String AUTOR, String TITULO, String nacionlaidad, int paginas) {
        // Info que pide al crear
        this.AUTOR = AUTOR;
        this.ISBN = ISBN;
        this.TITULO = TITULO;
        this.nacionlaidad = nacionlaidad;
        this.paginas = paginas;
    }
    
    // ---------- GETTERS ----------
    public static String getCOLLECION() {
        return COLLECION;
    }

    public String getISBN() {
        return ISBN;
    }

    public String getTITULO() {
        return TITULO;
    }

    public String getAUTOR() {
        return AUTOR;
    }

    public String getNacionlaidad() {
        return nacionlaidad;
    }

    public int getPaginas() {
        return paginas;
    }
        
    // ---------- SETTERS ----------
    public void setNacionlaidad(String nacionlaidad) {
        this.nacionlaidad = nacionlaidad;
    }

    public void setPaginas(int paginas) {
        this.paginas = paginas;
    }
    
    
    //---- METODOS DE LA CLASE -----
    
    @Override
    public String toString() {
        return "El libro " + TITULO + "con ISBN " + ISBN + " creador por el autor " + AUTOR + " tiene " + paginas + " páginas.";
    }

    
    
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘