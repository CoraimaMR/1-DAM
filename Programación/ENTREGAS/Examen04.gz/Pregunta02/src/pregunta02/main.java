
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 28 ene 2026     ⏰ Hora: 11:50:20
 *
 *  Nombre del programa : Examen04
 *
 *******************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package pregunta02;

public class main {

    public static void main(String[] args) {
        //Creo dos libros
        Libro l1=new Libro("001", "Lorenzo Silva", "La Marca del Meridiano");
        Libro l2=new Libro("002", "Pérez Gellida", "Memento Mori", "Española", 532);
        
        //Muestro información
        System.out.println("");
        System.out.println(l1.toString());        
        System.out.println(l2.toString());
        
        //Asigno páginas a l2
        l2.setPaginas(489);
        
        //Muestro información
        System.out.println("");
        System.out.println(l1.toString());        
        System.out.println(l2.toString());
        
        //Calculo más páginas
        System.out.println("");
        
        //--------COMPLETAR CÓDIGO--------
        
    }//main

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘