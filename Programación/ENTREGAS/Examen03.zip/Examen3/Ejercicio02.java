
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 22 ene 2026     ⏰ Hora: 18:20:02
 *
 *  Nombre del programa : Ejercicio02
 *
 *******************************************************/

/********************************* ENUNCIADO ***********************************
Leer un nombre completo (ej. "juan perez lopez")
Obtener la primera letra de cada palabra
Mostrar las iniciales en mayúsculas
*******************************************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package Examen3;
import java.util.Scanner;

public class Ejercicio02 {

    public static void main(String[] args) {
        
        // Declaración de variables
        String iniciales = "";
        String palabra = "";
        
        // Lectura y comprobación de datos introducidos por teclado
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduzca el nombre completo: ");
        String nombreCompleto = sc.nextLine().trim();
        
        // Empezamos a crear el interior del programa
        String[] palabras = nombreCompleto.split(" "); // Separo la frase en palabras
        
        for (int i = 0; i < palabras.length; i++) {
            palabra = palabras[i]; // Tomamos la palabra actual
            if (!palabra.isEmpty()) { // Verificamos que no esté vacía
                iniciales += palabra.substring(0, 1).toUpperCase(); // Tomamos inicial y convertimos a mayúscula
            }
        }
        
        // Mostramos el resultado
        System.out.println("Iniciales: " + iniciales);

    } //main()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘