
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 22 ene 2026     ⏰ Hora: 18:19:56
 *
 *  Nombre del programa : Ejercicio01
 *
 *******************************************************/

/********************************* ENUNCIADO ***********************************
Leer una frase
Verificar si contiene todas las letras de la a a la z
*******************************************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package Examen3;
import java.util.Scanner;

public class Ejercicio01 {

    public static void main(String[] args) {

        // Declaración de variables y constantes
        String alfabeto = "abcdefghijklmnñopqrstuvwxyz"; // nuestro alfabeto con ñ
        boolean contieneTodo = true; // asumimos que sí contiene todo
        
        // Lectura y comprobación de datos introducidos por teclado
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce una frase: ");
        String frase = sc.nextLine().toLowerCase(); // Convertimos a minúsculas
        
        // Empezamos a crear el interior del programa
        // Recorremos cada letra del alfabeto
        for (int i = 0; i < alfabeto.length(); i++) {
            char letra = alfabeto.charAt(i); // tomamos la letra en la posición i
            if (!frase.contains(String.valueOf(letra))) {
                contieneTodo = false; // si falta alguna letra, cambiamos a false
                break; // no hace falta seguir verificando
            }
        }

        // Mostramos el resultado
        if (contieneTodo) {
            System.out.println("La frase contiene todo el abecedario (incluyendo ñ).");
        } else {
            System.out.println("La frase NO contiene todo el abecedario (incluyendo ñ).");
        }

    } //main()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘