
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 22 ene 2026     ⏰ Hora: 18:20:09
 *
 *  Nombre del programa : Ejercicio03
 *
 *******************************************************/

/********************************* ENUNCIADO ***********************************
Introducir un numero en la secuencia del 0 al 10.
*******************************************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package Examen3;
import java.util.Scanner;

public class Ejercicio03 {

    public static void main(String[] args) {

        // Declaración de variables y constantes
        int numero, posicion;
        
        // Lectura y comprobación de datos introducidos por teclado
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduce un número: ");
        numero = sc.nextInt();
        
        System.out.print("Introduce la posicion del número: ");
        posicion = sc.nextInt();
        
        // Empezamos a crear el interior del programa
         if (posicion < 0 || posicion > 10) {
            System.out.println("Posición inválida.");
        } else {
            System.out.println("Secuencia del 0 al 10 con tu número extra:");

            for (int i = 0; i <= 10; i++) {
                // Insertamos el número extra antes de la posición indicada
                if (i == posicion) {
                    System.out.print(numero + " ");
                }
                // Mostramos el número normal
                System.out.print(i + " ");
            }
             System.out.println(); // Salto de linea
        }

    } //main()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘