
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package policias;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 13:23:02
* @version 1.0
*******************************************************************************/

public class Comisario extends Policia {

    // -------- CONSTRUCTOR --------
    public Comisario(String nombre, String telefono, int antiguedad) {
        super(nombre, telefono, antiguedad);
        this.incremento = 0.57;
    }
    
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘