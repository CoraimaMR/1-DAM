
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package policias;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 13:21:23
* @version 1.0
*******************************************************************************/

public class Policia {

    // --------- ATRIBUTOS ---------
    protected String nombre;
    protected String telefono;
    protected int antiguedad;
    private final double SUELDOBASE = 1500;
    protected double incremento;
    private double sueldo;
    
    // -------- CONSTRUCTOR --------
    public Policia(String nombre, String telefono, int antiguedad) {    
        this.nombre = nombre;
        this.telefono = telefono;
        this.antiguedad = antiguedad;
    }    

    // ---------- GETTERS ----------
    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public int getAntiguedad() {
        return antiguedad;
    }
    
    public double getSUELDOBASE() {    
        return SUELDOBASE;
    }

    public double getSueldo() {
        return sueldo;
    }    
    
    // ---------- SETTERS ----------
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }    
     
    //---- METODOS DE LA CLASE -----
    public void calcularSueldo(){
        this.sueldo = SUELDOBASE + (SUELDOBASE * this.incremento);
    } // calcularSueldo()
    
    public void imprimir() {
        System.out.println("******* AGENTE *******");
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Telefono: " + this.telefono);
        System.out.println("Sueldo: " + this.sueldo);
        System.out.println("Antigüedad: " + this.antiguedad);
    } // imprimir()
    
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘