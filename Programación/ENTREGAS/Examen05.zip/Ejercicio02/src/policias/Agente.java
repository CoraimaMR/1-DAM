
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package policias;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 13:22:18
* @version 1.0
*******************************************************************************/

public class Agente extends Policia {
    
    // -------- CONSTRUCTOR --------
    public Agente(String nombre, String telefono, int antiguedad) {
        super(nombre, telefono, antiguedad);
        this.incremento = 0.20;
    }
        
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘