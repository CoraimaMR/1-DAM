
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package policias;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 13:22:48
* @version 1.0
*******************************************************************************/

public class Inspector extends Policia {

    // -------- CONSTRUCTOR --------
    public Inspector(String nombre, String telefono, int antiguedad) {
        super(nombre, telefono, antiguedad);
        this.incremento = 0.35;
    }
    
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘