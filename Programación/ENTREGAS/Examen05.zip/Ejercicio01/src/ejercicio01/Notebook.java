
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package ejercicio01;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 12:01:22
* @version 1.0
*******************************************************************************/

public class Notebook extends Producto {

    // --------- ATRIBUTOS ---------
    private int bateria;
    private int peso;
    
    // -------- CONSTRUCTOR --------
    public Notebook(int bateria, String marca, int año, int precioAdquisicion, int peso) {
        super(marca, año, precioAdquisicion);
        this.bateria = bateria;
        this.peso = peso;   
        this.incremento = 0.20;
    }  

    // ---------- GETTERS ----------
    public int getBateria() {
        return bateria;
    }

    public int getPeso() {
        return peso;
    }
    
    // ---------- SETTERS ----------
    public void setBateria(int bateria) {
        this.bateria = bateria;
    }
    
    public void setPeso(int peso) {
        this.peso = peso;
    }

    //---- METODOS DE LA CLASE -----
    @Override
    public void imprimir() {        
        System.out.println("NOTEBOOK");
        super.imprimir();
        System.out.println("Batería: " + this.bateria);     
        System.out.println("Peso: " + this.peso);
    } // imprimir()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘