
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package ejercicio01;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 12:01:47
* @version 1.0
*******************************************************************************/

public class Pantalla extends Producto {

    // --------- ATRIBUTOS ---------
    private int herramienta;
    private String resolucion;
    
    // -------- CONSTRUCTOR --------
    public Pantalla(int herramienta, String resolucion, String marca, int año, int precioAdquisicion) {
        super(marca, año, precioAdquisicion);
        this.herramienta = herramienta;
        this.resolucion = resolucion;   
        this.incremento = 0.30;
    }  

    // ---------- GETTERS ----------
    public int getHerramienta() {
        return herramienta;
    }

    public String getResolucion() {
        return resolucion;
    }    
    
    // ---------- SETTERS ----------
    public void setHerramienta(int herramienta) {
        this.herramienta = herramienta;
    }

    public void setResolucion(String resolucion) {
        this.resolucion = resolucion;
    }    
    
    //---- METODOS DE LA CLASE -----
    @Override
    public void imprimir() {        
        System.out.println("PANTALLA TÁCTIL");
        super.imprimir();
        System.out.println("Número de herramientas interactivas: " + this.herramienta);
        System.out.println("Resolución: " + this.resolucion);
    } // imprimir()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘