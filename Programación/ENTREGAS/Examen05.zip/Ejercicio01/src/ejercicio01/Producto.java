
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package ejercicio01;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 12:00:40
* @version 1.0
*******************************************************************************/

public class Producto {

    // --------- ATRIBUTOS ---------
    private String marca;
    private int año;
    private int precioAdquisicion;
    private double precioVenta = 0;
    protected double incremento;
    
    // -------- CONSTRUCTOR --------
    public Producto(String marca, int año, int precioAdquisicion) {
        this.marca = marca;
        this.año = año;
        this.precioAdquisicion = precioAdquisicion;
    }    
        
    // ---------- GETTERS ----------
    public String getMarca() {
        return marca;
    }

    public int getAño() {
        return año;
    }

    public double getPrecioAdq() {
        return precioAdquisicion;
    }
    
    // ---------- SETTERS ----------
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public void setPrecioAdq(double precioAdq) {
        this.precioAdquisicion = precioAdquisicion;
    }
    
    //---- METODOS DE LA CLASE -----
    public void precioVenta() {
        this.precioVenta = this.precioAdquisicion + (this.precioAdquisicion * this.incremento);
    } //precioVenta()
    
    public void imprimir() {
        System.out.println(this.marca+ " año " + this.año + ". Precio de adquisición: " + this.precioAdquisicion);
        System.out.println("PVP: " + this.precioVenta);      
    } // imprimir()
        
} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘