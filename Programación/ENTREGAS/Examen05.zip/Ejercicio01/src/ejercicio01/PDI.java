
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package ejercicio01;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 12:01:40
* @version 1.0
*******************************************************************************/

public class PDI extends Producto {

    // --------- ATRIBUTOS ---------
    private boolean capacitiva;
    private String resolucion;
    
    // -------- CONSTRUCTOR --------
    public PDI(boolean capacitiva, String resolucion, String marca, int año, int precioAdquisicion) {
        super(marca, año, precioAdquisicion);
        this.capacitiva = capacitiva;
        this.resolucion = resolucion;   
        this.incremento = 0.28;
    }  

    // ---------- GETTERS ----------
    public boolean getCapacitiva() {
        return capacitiva;
    }

    public String getResolucion() {
        return resolucion;
    }
    
    // ---------- SETTERS ----------
    public void setCapacitiva(boolean capacitiva) {
        this.capacitiva = capacitiva;
    }

    public void setResolucion(String resolucion) {
        this.resolucion = resolucion;
    }
    
    //---- METODOS DE LA CLASE -----
    @Override
    public void imprimir() {        
        System.out.println("PDI");
        super.imprimir();
        if (capacitiva) {
            System.out.println("Tipo: Capacitiva");
        }
        System.out.println("Resolución: " + this.resolucion);
    } // imprimir()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘