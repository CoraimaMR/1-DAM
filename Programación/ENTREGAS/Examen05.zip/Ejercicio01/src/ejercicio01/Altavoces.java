
// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package ejercicio01;

/*******************************************************************************
* DESCRIPCIÓN
*
* @author 🌟 Coraima Mera Rodríguez 🌟
* @since 🗓️ Fecha: 8 abr 2026 ⏰ Hora: 12:01:06
* @version 1.0
*******************************************************************************/

public class Altavoces extends Producto {

    // --------- ATRIBUTOS ---------
    private String calidad;
    private int peso;
    
    // -------- CONSTRUCTOR --------
    public Altavoces(String calidad, String marca, int año, int precioAdquisicion, int peso) {
        super(marca, año, precioAdquisicion);
        this.calidad = calidad;
        this.peso = peso;   
        this.incremento = 0.15;
    }  

    // ---------- GETTERS ----------
    public String getCalidad() {
        return calidad;
    }

    public int getPeso() {
        return peso;
    }
    
    // ---------- SETTERS ----------
    public void setCalidad(String calidad) {
        this.calidad = calidad;
    }
    
    public void setPeso(int peso) {
        this.peso = peso;
    }

    //---- METODOS DE LA CLASE -----
    @Override
    public void imprimir() {        
        System.out.println("ALTAVOCES");
        super.imprimir();
        System.out.println("Calidad: " + this.calidad);     
        System.out.println("Peso: " + this.peso);
    } // imprimir()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘