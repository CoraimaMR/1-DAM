
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 24 nov 2025     ⏰ Hora: 11:51:56
 *
 *  Nombre del programa : Ejercicio01
 *
 *******************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package Examen2;
import java.util.Scanner;

public class Ejercicio01 {

    public static void main(String[] args) {

        // Declaración de variables
        int base, promocion, iva;
        float total = 0;
        
        // Lectura y comprobación de datos introducidos por teclado
        // No hace falta comprobar
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduzca el precio (baseimponible):");
        base = sc.nextInt();
        
        System.out.print("Introduzca el  codigo promocional (1:nopromo, 2:mitad, 3:menos5, 4:porcentaje5):");
        promocion = sc.nextInt();
        
        System.out.print("Introduzca el IVA (1:superrreducido, 2:reducido, 3:general):");
        iva = sc.nextInt();
        
        // Empezamos a crear el interior del programa
        
        // Segun se elige en la promocion se hara un descuento o otro
        switch (promocion) {
            case 1: total = base;
                break;
            case 2: total = base/2;
                break;
            case 3: total = base-5;
                break;
            case 4: total = (float) (base-(base*0.05));
                break;
            default:
                System.out.println("ERROR. Introduzca un número del 1 al 4.");        
        }
        
        // Igual que pasa en el anterior lo hacemos con el IVA
        switch (iva) {
            case 1: total -= total*0.21;
                break;
            case 2: total -= total*0.1;
                break;
            case 3: total -= total*0.04;
                break;
            default:
                System.out.println("ERROR. Introduzca un número del 1 al 4.");        
        }

        // Mostramos el resultado
        System.out.println("El total a pagar es = "+total);
    }
}

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘