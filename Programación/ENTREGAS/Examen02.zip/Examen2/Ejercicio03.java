
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 24 nov 2025     ⏰ Hora: 11:52:58
 *
 *  Nombre del programa : Ejercicio03
 *
 *******************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package Examen2;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio03 {

    public static void main(String[] args) {

        // Declaración de variables
        int altura = 0;
        boolean seguir, pez = false;
        int espacioAfuera, espacioAdentro;
        int posicionPez = 0, lineaPez = 0;
        
        // Lectura y comprobación de datos introducidos por teclado
        Scanner sc = new Scanner(System.in);
        
        do {            
            seguir = false;
            try {
                System.out.print("Introduzca la altura de la figura (min 5): ");
                altura = sc.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Valor no válido, tipo de excepción " + e.toString());                
                sc.nextLine();
                seguir = true;
            }
        } while (seguir || altura<5);
        
        // DIBUJO LA FIGURA
        
        // Calculos para la figura
        espacioAfuera = 1;
        espacioAdentro = altura-3;
        
        // Linea aleatoria para el pez
        lineaPez = (int)(Math.random()*altura-2)+1;
        
         for (int i = 0; i < altura; i++) {  // Dibujamos la primera linea
             System.out.print("*");
        }
        System.out.println("");  // Siguiente linea
        
        for (int i = 0; i < altura-1; i++) {  // Dibujamos las demas lineas memos la ultima
            if (i == lineaPez) pez = true;  // Si es la linea que contiene el pez lo dibujamos despues
            
            for (int j = 0; j < espacioAfuera; j++) {  // Espacio en blanco antes de la linea
                System.out.print(" ");
            }
            System.out.print("*");  // Primer "*" de la linea
            
            if (pez) posicionPez = (int) (Math.random()*espacioAdentro);  // Posicion aleatoria en la linea para el pez
            for (int j = 0; j < espacioAdentro; j++) {  // Dibujamos los espacio de adentro de la figura
               
                if (pez && posicionPez == j) {  // Si dibujamos el pez y coincide la posicion
                    System.out.print("&");  // Mostramos pez
                    pez = false;  // No mostramos mas el pez, solo hay 1
                } else {
                    System.out.print(" ");  // Mostramos un espacio en blanco
                }
            }
            if (i!=altura-2) System.out.print("*");  // Segundo "*" de la linea
            
            System.out.println("");  // Siguiente linea
            // Preparacion para la siguiente linea
            espacioAfuera++;
            espacioAdentro--;
        }
    }
}

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘