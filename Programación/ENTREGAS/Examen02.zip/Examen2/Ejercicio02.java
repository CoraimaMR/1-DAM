
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 24 nov 2025     ⏰ Hora: 11:52:48
 *
 *  Nombre del programa : Ejercicio02
 *
 *******************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package Examen2;
import java.util.Scanner;

public class Ejercicio02 {

    public static void main(String[] args) {

        // Declaración de variables
        short n, divisor, copia;
        
        // Lectura y comprobación de datos introducidos por teclado
        // No hace falta comprobar
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Introduzca un número:");
        n = sc.nextShort();
        
        System.out.print("Introduzca un divisor:");
        divisor = sc.nextShort();
        
        // Mostramos y calculamos el resultado
        copia = (short) (n-1);  // Hacemos una copia para no perder el número
        
        System.out.println("ANTERIORES :");
        for (int i = 0; i < 5 & copia > 0;) {  // Paramos si ya tiene 5 numeros mostrados o la cuenta ya es 0 y como no es entero paramos
            if (copia%divisor==0) {  // Si el numero es divisible lo mostramos
                System.out.println(copia);
                i++;  // Solo contamos cuando se muestra el numero
            }
            copia--;  // Vamos cambiando de número
        }
        System.out.println("");  // Siguiente linea
        
        copia = (short) (n+1);  // Hacemos una copia para no perder el número
        System.out.println("POSTERIORES :");
        for (int i = 0; i < 5;) {  // Paramos hasta tener 5 numeros
            if (copia%divisor==0) {  // Si el numero es divisible lo mostramos
                System.out.println(copia);
                i++;  // Solo contamos cuando se muestra el numero
            }
            copia++;  // Vamos cambiando de número
        }
        System.out.println("");  // Siguiente linea
    }
}

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘