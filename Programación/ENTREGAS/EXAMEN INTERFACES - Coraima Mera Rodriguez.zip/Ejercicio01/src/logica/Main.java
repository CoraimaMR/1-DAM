
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 8 jun 2026     ⏰ Hora: 11:59:38
 *
 *  Nombre del programa : Main
 *
 *******************************************************/

/******************************** EXPLICACIÓN **********************************
Lo que podemos ver en este ejercicio es como he creado un a interfaz grafica de
para generar numeros aleatorios y decir si es par o impar. Para ello he creados  
3 radio butons con su repectivo grupo de botones para que no se selccionen mas
de uno y cuanddo se de a un buton de abajo llamara su respectivo evento que 
actualizara el label correspondiente.
*******************************************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package logica;
import gui.Ventana;

public class Main {

    public static void main(String[] args) {
        
        Ventana window = new Ventana(); // Creo la  nueva instancia "window"
        window.setVisible(true); // Activo la ventana
        window.setLocationRelativeTo(null); // Posicion de la ventana al ejecutar: medio
        
    } //main()
    
    public static int numeroAleatorio(int max, int min) {
        return (int) (Math.random()*max) + min;
    } // numeroAleatorio()
    
    public static boolean esPar(int numero) {
        // Devuelve true si el residuo de dividir entre 2 es cero
        return numero % 2 == 0;
    }//esPar()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘