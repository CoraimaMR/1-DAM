
/*******************************************************
 *
 *             💻  PROGRAMACIÓN EN JAVA  💻
 *
 *  Autora:    🌟 Coraima Mera Rodríguez 🌟
 *  Curso:       Programación de 1º  DAM
 *
 *     🗓️ Fecha: 8 jun 2026     ⏰ Hora: 11:59:38
 *
 *  Nombre del programa : Main
 *
 *******************************************************/

/******************************** EXPLICACIÓN **********************************
En este ejercicio o que hecho es hacer la interfaz que ve el usuario en varios
bloques como se puede ver para que este ordenado y me ayude  hacerlo mas rapido,
sencillo y bonito. Despues de hacer la interfaz he ido enlazando los eventos que
necesitaba a las plantillas dadas. Como el del boton abrir a la plantilla Ficeros
o el de los radio butons que era en la plantilla Regex donde tambien me daban 
las constantes de las expreiones irregulares.
* 
Para que no se seleccionaran a la vez dos radios butons lo meti en un grupo de
botones que impide eso. Y para que te deje seleccionar un archivo hace falta el
FileChooser.
*******************************************************************************/

// ┌────────────────────────────────────┐
// │ 🔹🔹🔹 INICIO DEL PROGRAMA 🔹🔹🔹 │
// └────────────────────────────────────┘

package logica;
import gui.Ventana;

public class Main {

    public static void main(String[] args) {
        
        Ventana window = new Ventana(); // Creo la  nueva instancia "window"
        window.setVisible(true); // Activo la ventana
        window.setLocationRelativeTo(null); // Posicion de la ventana al ejecutar: medio
        
    } //main()

} // clase principal

// ┌────────────────────────────────────┐
// │  🔸🔸🔸 FIN DEL PROGRAMA 🔸🔸🔸   │
// └────────────────────────────────────┘