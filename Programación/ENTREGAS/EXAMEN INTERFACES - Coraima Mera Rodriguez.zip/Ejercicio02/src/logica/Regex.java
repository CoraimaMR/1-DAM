/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package logica;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Jesús Pérez 
 * Clase que contiene toda la gestión de las expresiones regulares
 */
public class Regex {
    //******************* ATRIBUTOS
    //--- Constantes estáticas que describen cada una de las expresiones regulares a localizar
    
    public static final String REGEX_IP="((25[0-5]|2[0-4][0-9]|[1]?[0-9]?[0-9])\\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
    public static final String REGEX_TWITTER="@([A-Za-z0-9_-])+";
    public static final String REGEX_MATRICULA="[0-9]{4}[BCDFGHJKLMNPRSTVWXYZ]{3}";
    
    public static final String REGEX_FECHA="([0][1-9]|[12][0-9]|3[01])(\\/)([0][1-9]|[1][012])()\\/((19|20|21|22)[0-9]{2})";
    
    public static final String REGEX_MAC="([0-9A-F]{2}[:-]){5}([0-9A-F]{2})";
    public static final String REGEX_EMAIL="[a-z0-9]+(\\.[a-z0-9]+)*@[a-z0-9-_]+(\\.[a-z0-9-_]+)*(\\.([a-z])+)";
    public static final String REGEX_TFNO="[679]{1}[0-9]{2}[-]?[0-9]{6}";
    
    //******************* MÉTODOS
    /**
     * Método utilizado para localizar todas las expresiones regulares a excepción de las fechas
     * @param regex Constante estática que contiene la expresión regular a localizar
     * @param txtArea Área de texto que incluye en texto donde se va a buscar la expresión regular indicada en el argumento 'regex'
     * @param txtaResultado Área de texto que muestra las expresiones regulares encontradas (matrícula, IP...)
     */
    public static void localizaRegex(String regex, JTextArea txtArea, JTextArea txtaResultado){
        String encontrado="";      
        
        txtaResultado.setText("");
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(txtArea.getText());
        
        while (matcher.find()) {
            encontrado= matcher.group();
            txtaResultado.setText(txtaResultado.getText()+"\n"+encontrado);
        }//while
        
    }//localizaRegex()
    
    /**
     * Método utilizado para localizar las fechas como expresiones regulares
     * @param txtArea Área de texto que incluye en texto donde se va a buscar la fecha
     * @param txtaResultado Área de texto que muestra las fechas encontradas
     */
    public static void localizaFecha(JTextArea txtArea, JTextArea txtaResultado){
        String encontrado="";
        
        txtaResultado.setText("");
        
        Pattern pattern = Pattern.compile(Regex.REGEX_FECHA);
        Matcher matcher = pattern.matcher(txtArea.getText());
        
        while (matcher.find()) {
            encontrado= matcher.group();
            if (esFechaCorrecta(encontrado)) {
                txtaResultado.setText(txtaResultado.getText()+"\n"+encontrado);
            }
        }//while
    }//localizaFecha()
    
    
    //******************* MÉTODOS FECHA (private)
    
    private static boolean esFechaCorrecta(String fecha){
        boolean resultado=true;
        int dia, mes, agnus;
        String[] trozos;
        
        trozos=trocearFecha(fecha);
        
        dia=extraerDia(trozos);
        mes=extraerMes(trozos);
        agnus=extraerAgnus(trozos);
        
        switch (mes) {
            case 2://febrero

                if (dia>29) {
                    resultado=false;
                } else {
                    if (dia==29) {
                        if (agnus%4!=0) {
                            resultado=false;
                        } else {
                            if (agnus%100==0&&agnus%400!=0) {
                                resultado=false;
                            }
                        }
                    } 
                }
                    
            break;
            
            default:
                if ((mes==4||mes==6||mes==9||mes==11)&&dia==31) resultado=false;
            
        }//switch
        
        return resultado;
        
    }//esFechaCorrecta()
    
      
    private static String[] trocearFecha(String fecha){
        String[] trozos;
        trozos=fecha.split("/");
        return trozos;
    }//trocearFecha()
    
    
    private static int extraerDia(String trozos[]){
        return Integer.parseInt(trozos[0]);
    }//extraerDia()
    
    
    private static int extraerMes(String trozos[]){
        return Integer.parseInt(trozos[1]);
    }//extraerMes()
    
    
    private static int extraerAgnus(String trozos[]){
        return Integer.parseInt(trozos[2]);
    }//extraerAgnus()
    

}//class
