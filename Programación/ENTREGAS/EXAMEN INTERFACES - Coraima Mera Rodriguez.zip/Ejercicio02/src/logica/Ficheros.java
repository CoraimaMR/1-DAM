/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * Clase que gestiona la apertura de un fichero de texto
 * @author usuario
 */
public class Ficheros {
    
    /**
     * Método que abre un fichero de texto y lo vuelca en un JTextArea
     * @param jfc JFileChooser utilizado para seleccionar el fichero que se quiere abrir
     * @param txa JTextArea en el que se va a mostrar el texto del fichero seleccionado
     * @throws FileNotFoundException Excepción arrojada si no se puede abrir el fichero o se cancela la operación
     */
    public static void abrirFichero(JFileChooser jfc, JTextArea txa) throws FileNotFoundException{
        int seleccion;
        String linea="";
        
        //Abrir un fichero para lectura
        seleccion=jfc.showOpenDialog(null);
        
        if (seleccion==JFileChooser.APPROVE_OPTION) {
            
            File f=jfc.getSelectedFile();
            
            if (!f.exists()) throw new FileNotFoundException("Error al abrir el fichero");               
         
            Scanner lector=new Scanner(f);

            //Borrar el área de texto
            txa.setText("");

            while (lector.hasNext()) {
                linea=lector.nextLine();
                txa.setText(txa.getText()+linea+"\n");
            }
            lector.close();
            
        } else throw new FileNotFoundException("Error al abrir el fichero");
        
        
    }//abrirFichero()
    
}
